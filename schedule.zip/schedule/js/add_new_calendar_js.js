jQuery(document).ready(function ($) { //wrapper



    $(".add_new_calendar_button").on("click", function (event) {
        
        var texts=$("#add_new_calendar_input_text");
        var butt = $('.status_vynanya_add');
        var databd=texts.val();
        var p=(/\s/g.test(databd));
        if(!p){
        $.ajax({ //добавляє в бд дані і видаляє хуком schedule_upData_Dd 
            url: "/wp-admin/admin-ajax.php",
            method: 'post',
            data: {
                action: 'schedule_upDataBase',
                dataq: databd

            },
            success: function (response) {
               response = response.slice(0, -1);
              // console.log(response);
                butt.html(databd+" "+response);
            }
        });
}
        else{
            alert("Введіть назву без пробілів");
        }
    });


 $(".delete_calendar_button").on("click", function (event) {
        var buttq = $('.status_vynanya_delete');
     var str = "";
            $(".calendar_obraty_month_selecti").change(function () {
                    $(".calendar_obraty_month_selecti option:selected").each(function () {
                        str = $(this).text();
                    });
                })
                .trigger("change");
        //console.log(str);
        
        $.ajax({ //добавляє в бд дані і видаляє хуком schedule_upData_Dd 
            url: "/wp-admin/admin-ajax.php",
            method: 'post',
            data: {
                action: 'schedule_upDeleteDataBase_Dd',
                datadeletes: str
            },
            success: function (response) {
                response = response.slice(0, -1);
                //console.log(response);
                buttq.html(str+" "+response);

            }
        });

    });




});
