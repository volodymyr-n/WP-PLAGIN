<div class="schedule_opt_all_onwe">
<div class="schedule_opt_all">
<div class="schedule_opt_vyb"><strong>Виберіть об'єкт:</strong></div>
   <div class="schedule_opt"><select name="hero" class="calendar_obraty_month_select">
<?php
    global $wpdb;
    $sql=" DESCRIBE `wp_schedule`";
 $myrows =   $wpdb->get_results( $sql, ARRAY_N);
    $dateall='<option></option>';
    $i=0;
       ;
    while(!empty($myrows[$i][0])){
         $dateall .= '<option>'.$myrows[$i][0].' </option>  ';
          $i++;
    }
          $i++;
     echo $dateall;?>
   </select> 
</div>
   </div>
</div>
    <div id="caleandar">
</div>

