<div class="schedule_app_update_block">
   <div class="add_new_calendar">
    <div>
        <h3>Створити новий календар</h3>
        <label>Введіть назву нового календара без пробілів</label>
    <input type="text" id="add_new_calendar_input_text">
<button class="add_new_calendar_button">Створити</button>
   <div class="status_vynanya_add"></div>
    </div>
    
</div>
<div class="delete_calendar">
    <div class="delete_caleandars">
        <h3>Видалення календаря  з БД</h3>
        <label>Виберіть календар для видалення (безповоротно)</label>
         <div class="schedule_opti"><select name="heroi" class="calendar_obraty_month_selecti">
<?php
    global $wpdb;
    $sql=" DESCRIBE `wp_schedule`";
 $myrows =   $wpdb->get_results( $sql, ARRAY_N);
    $dateall='<option></option>';
    $i=0;
       ;
    while(!empty($myrows[$i][0])){
         $dateall .= '<option>'.$myrows[$i][0].' </option>  ';
          $i++;
    }
          $i++;
     echo $dateall;?>
   </select> 
</div>
<button class="delete_calendar_button">Видалити</button>
   <div class="status_vynanya_delete"></div>
    </div>
</div>
</div>