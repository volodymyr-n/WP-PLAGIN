<?php
/**
 * Plugin Name: Schedule
 */

add_action( 'plugins_loaded', 'true_load_plugin_textdomain' );
 
function true_load_plugin_textdomain() {
	load_plugin_textdomain( 'schedule', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' ); 
}

function true_schedule_func($atts, $content){ 

        wp_register_style('your_namespace', plugins_url('/css/schedule_theme_calendar.css',__FILE__ ));
    wp_enqueue_style('your_namespace');
    
        wp_enqueue_script( 'calendar_schedule_script_shord',
        plugins_url( '/js/calendar_schedule.js', __FILE__ ),
        array( 'jquery' )
    );
      $title_nonce = wp_create_nonce( 'title_example' );
    wp_localize_script( 'calendar_schedule_script_shord', 'my_ajax_obj', array(
       'ajax_url' => admin_url( 'admin-ajax.php' ),
       'nonce'    => $title_nonce,
    ) );
         return ' <div id="caleandarq" namerow='.$content.'>
</div>';
          
        
	// никаких echo, только return
}
add_shortcode( 'calendar_schedule', 'true_schedule_func' );
add_action('wp_ajax_schedule_namecaleandar', 'my_action_namecaleandar');
add_action('wp_ajax_nopriv_namecaleandar', 'my_action_namecaleandar');
function my_action_namecaleandar() {
    echo $_POST['namecaleandar']; 
}
add_action('wp_ajax_schedule_namecaleandarid', 'my_action_namecaleandarid');
add_action('wp_ajax_nopriv_namecaleandarid', 'my_action_namecaleandarid');
function my_action_namecaleandarid() {
    global $namecaleandarid;
echo $namecaleandarid;
    echo "---";
    echo $_POST['namecaleandarid']; 
}

 add_action( 'admin_enqueue_scripts', 'my_enqueue');
function my_enqueue( $hook ) {
    wp_register_style('your_namespace', plugins_url('/css/admin_schedule_theme_calendar.css',__FILE__ ));
    wp_enqueue_style('your_namespace');
          wp_enqueue_script( 'add_new_calendar_js',
        plugins_url( '/js/add_new_calendar_js.js', __FILE__ ),
        array( 'jquery' )
    );
      $title_nonce = wp_create_nonce( 'title_example' );
    wp_localize_script( 'add_new_calendar_js', 'my_ajax_obj', array(
       'ajax_url' => admin_url( 'admin-ajax.php' ),
       'nonce'    => $title_nonce,
    ) );
        wp_enqueue_script( 'ajax-script',
        plugins_url( '/js/admin_calendar_schedule.js', __FILE__ ),
        array( 'jquery' )
    );
      $title_nonce = wp_create_nonce( 'title_example' );
    wp_localize_script( 'ajax-script', 'my_ajax_obj', array(
       'ajax_url' => admin_url( 'admin-ajax.php' ),
       'nonce'    => $title_nonce,
    ) );
    if( 'myplugin_settings.php' != $hook ) return;

}


require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
register_uninstall_hook( __FILE__, 'schedule_delete_Db_Tabel' );
dbDelta( $sql );
function schedule_delete_Db_Tabel(){
   global $wpdb;
   $table_name = $wpdb->prefix."schedule"; 
$sql = "DROP TABLE IF EXISTS $table_name";
 $wpdb->query($sql);
}


register_activation_hook( __FILE__, 'schedule_add_Db_Tabel' );
dbDelta( $sql );
function schedule_add_Db_Tabel(){
   global $wpdb;
   $table_name = $wpdb->prefix."schedule"; 
   $charset_collate = $wpdb->get_charset_collate();
$sql = "CREATE TABLE $table_name (`TEST` INT NULL 
) $charset_collate;";
    
    require_once (ABSPATH.'wp-admin/includes/upgrade.php');
dbDelta ($sql);
wp_enqueue_script('jquery');
}

/*
 * Добавляем новое меню в Админ Консоль 
 */
// Хук событие 'admin_menu', запуск функции 'mfp_Add_My_Admin_Link()'
add_action( 'admin_menu', 'mfp_Add_My_Admin_Link');
add_action( 'wp_ajax_admin_menu', 'mfp_Add_My_Admin_Link');
// Добавляем новую ссылку в меню Админ Консоли
function mfp_Add_My_Admin_Link()
{
    add_menu_page('Розклад', 'Розклад', 'manage_options',  'schedule/includes/schedule_function.php');

add_submenu_page( 'schedule/includes/schedule_function.php', 'Редагування розкладу ', 'Редагування розкладу', 'manage_options', 'schedule/includes/schedule_function.php');

add_submenu_page( 'schedule/includes/schedule_function.php', 'Додати новий календар', 'Редагування календарів', 'manage_options',  'schedule/includes/add_new_calendar.php');
}
function schedule_upDataBase_Dd(){
    global $wpdb;
    $db_table_name=$_REQUEST['dataq'];
    $sql='ALTER TABLE `wp_schedule` ADD `'.$db_table_name.'` VARCHAR(20) NULL FIRST';
    

    $wpdb->query($sql);
echo 'добавлено';
}

add_action('wp_ajax_schedule_upDataBase', 'schedule_upDataBase_Dd');

function schedule_upDeleteDataBase_Dd(){
    global $wpdb;
    $db_table_name=$_REQUEST['datadeletes'];
    $sql='ALTER TABLE `wp_schedule` DROP '.$db_table_name.'';
    $wpdb->query($sql);
echo 'видалено';
}
add_action('wp_ajax_schedule_upDeleteDataBase_Dd', 'schedule_upDeleteDataBase_Dd');
add_action('wp_ajax_nopriv_schedule_upDeleteDataBase_Dd', 'schedule_upDeleteDataBase_Dd');

add_action('wp_ajax_schedule_upData_Dd', 'my_action_callback');
add_action('wp_ajax_nopriv_schedule_upData_Dd', 'my_action_callback');
function my_action_callback() {
    global $wpdb;
    $date=(int)$_REQUEST['date'];
    $month=(int)$_REQUEST['month'];
    $year=(int)$_REQUEST['year'];
    $dateallmis=$date.$month.$year;
    $danitabelupdata=$_REQUEST['danitabelupdata'];
   
	$sql="SELECT ".$danitabelupdata." FROM `wp_schedule` WHERE ".$danitabelupdata." = '".$dateallmis."'";
    
 $myrows =   $wpdb->get_results( $sql, ARRAY_N); 
  //  $landID = $_POST['landID'];
    $f;
    if($myrows[0]==null){
        
        $sql1="UPDATE wp_schedule SET ".$danitabelupdata." = '".$dateallmis."' WHERE ".$danitabelupdata." IS NULL LIMIT 1";
        
        if(empty($wpdb->query($sql1))){
            
            $sql4="INSERT INTO wp_schedule (".$danitabelupdata.") VALUES ('".$dateallmis."')";
         
            $wpdb->query($sql4);

        }
 
        $f='<div class="zanyato_schedule">Зайнято</div>';
    }
    else{
        $sql2="UPDATE wp_schedule SET ".$danitabelupdata." = NULL WHERE ".$danitabelupdata." = '".$dateallmis."' LIMIT 1";
        $wpdb->query($sql2);
        $f='<div class="vilno_schedule">Вільно</div>';
    }
    echo $f;
    
}

add_action('wp_ajax_schedule_vilno_zanyato', 'my_action_vilno_zanyato');
add_action('wp_ajax_nopriv_schedule_vilno_zanyato', 'my_action_vilno_zanyato');
function my_action_vilno_zanyato() {
    global $wpdb;
    $dani= $_REQUEST['barabaa'];

    if("id"==($_REQUEST['barabaa'])){
        $name_data_base_table_kolonka="id";
    }
    else{$name_data_base_table_kolonka=$_REQUEST['barabaa'];}

    $sql='SELECT '.$name_data_base_table_kolonka.' FROM `wp_schedule` WHERE '.$name_data_base_table_kolonka.' IS NOT NULL';
    
  $myrows =  $wpdb->get_results( $sql, ARRAY_N);
    $dateall='{';
    $i=0;
    while(!empty($myrows[$i][0])){
        if(empty($myrows[$i+1][0])){
      $dateall .= '"'.$myrows[$i][0].'" :{}  ';
    }else{
          $dateall .= '"'.$myrows[$i][0].'" :{}, ';
          
        }
          $i++;
    }
    $dateall .="}";
     echo $dateall;
}
add_action('wp_ajax_schedule_location_stan', 'my_action_location_stan');
add_action('wp_ajax_nopriv_schedule_location_stan', 'my_action_location_stan');
add_action( 'plugins_loaded', 'true_plugin_language' );
 
function true_plugin_language() {
	load_plugin_textdomain( 'schedule', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' ); 
}
function my_action_location_stan() {	

// Локализация
    _e('Зайнято','schedule');
			 
	
}


add_action('wp_ajax_schedule_location_months', 'my_action_location_months');
add_action('wp_ajax_nopriv_schedule_location_months', 'my_action_location_months');

 

function my_action_location_months(){
	 $monts='{"'.__('Січень','schedule').'" :{},
						  "'.__('Лютий','schedule').'" :{},
						  "'.__('Березень','schedule').'" :{},
						  "'.__('Квітень','schedule').'" :{},
						  "'.__('Травень','schedule').'" :{},
						  "'.__('Червень','schedule').'" :{},
						  "'.__('Липень','schedule').'" :{},
						  "'.__('Серпень','schedule').'" :{},
						  "'.__('Вересень','schedule').'" :{},
						  "'.__('Жовтень','schedule').'" :{},
						  "'.__('Листопад','schedule').'" :{},
						  "'.__('Грудень','schedule').'" :{}
						  }';
echo $monts;
}
add_action('wp_ajax_schedule_location_day', 'my_action_location_day');
add_action('wp_ajax_nopriv_schedule_location_day', 'my_action_location_day');

 
function my_action_location_day(){
	 $day='{
						  "'.__('Пн','schedule').'" :{},
						  "'.__('Вт','schedule').'" :{},
						  "'.__('Ср','schedule').'" :{},
						  "'.__('Чт','schedule').'" :{},
						  "'.__('Пт','schedule').'" :{},
						  "'.__('Сб','schedule').'" :{},
						  "'.__('Нд','schedule').'" :{}
						  }';
echo $day;
}